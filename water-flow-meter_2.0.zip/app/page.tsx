"use client"

import { useState, useEffect } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Slider } from "@/components/ui/slider"
import {
  DropletIcon,
  History,
  AlertTriangle,
  Target,
  BarChart3,
  Calendar,
  AlertCircle,
  Droplets,
  ContainerIcon as Tank,
  Bell,
  BellOff,
} from "lucide-react"

export default function WaterMeterSystem() {
  // Estados para simulação de dados
  const [currentFlow, setCurrentFlow] = useState(2.5)
  const [totalVolume, setTotalVolume] = useState(1250.45)
  const [dailyUsage, setDailyUsage] = useState(125.5)
  const [monthlyUsage, setMonthlyUsage] = useState(3750.8)
  const [monthlyTarget, setMonthlyTarget] = useState(4000)
  const [leakDetected, setLeakDetected] = useState(false)
  const [costPerLiter, setCostPerLiter] = useState(0.003) // R$ 3,00 por m³

  // Estados para caixa d'água
  const [tankLevel, setTankLevel] = useState(65) // Porcentagem
  const [tankCapacity, setTankCapacity] = useState(1000) // Litros
  const [tankAlertLow, setTankAlertLow] = useState(20) // Alerta de nível baixo (%)
  const [tankAlertMid, setTankAlertMid] = useState(50) // Alerta de nível médio (%)
  const [tankAlertHigh, setTankAlertHigh] = useState(90) // Alerta de nível alto (%)
  const [tankAlertsEnabled, setTankAlertsEnabled] = useState(true)

  // Histórico de nível da caixa
  const [tankHistory, setTankHistory] = useState([60, 75, 68, 72, 70, 65])

  // Simulação de dados históricos
  const dailyData = [65, 85, 125, 95, 115, 125.5]
  const monthlyData = [3200, 3400, 3100, 3600, 3500, 3750.8]

  // Atualização simulada de fluxo e nível da caixa
  useEffect(() => {
    const interval = setInterval(() => {
      // Atualiza fluxo
      setCurrentFlow((prev) => {
        const variation = (Math.random() - 0.5) * 0.5
        return Number((prev + variation).toFixed(2))
      })

      // Simula variação do nível da caixa
      setTankLevel((prev) => {
        const variation = (Math.random() - 0.5) * 2
        const newLevel = prev + variation
        return Math.min(Math.max(newLevel, 0), 100) // Mantém entre 0 e 100
      })
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  // Cálculo de custos
  const calculateCost = (volume: number) => {
    return (volume * costPerLiter).toFixed(2)
  }

  // Determina o status da caixa d'água
  const getTankStatus = () => {
    if (tankLevel <= tankAlertLow) return { status: "Baixo", color: "destructive" }
    if (tankLevel <= tankAlertMid) return { status: "Médio-Baixo", color: "warning" }
    if (tankLevel <= tankAlertHigh) return { status: "Médio-Alto", color: "default" }
    return { status: "Cheio", color: "success" }
  }

  // Calcula o volume atual na caixa
  const getCurrentTankVolume = () => {
    return ((tankLevel / 100) * tankCapacity).toFixed(0)
  }

  return (
    <div className="container mx-auto p-4 max-w-6xl">
      <h1 className="text-3xl font-bold mb-6">Sistema de Monitoramento de Água</h1>

      <Tabs defaultValue="dashboard" className="space-y-4">
        <TabsList className="grid grid-cols-2 md:grid-cols-6 gap-2">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="tank">Caixa d'Água</TabsTrigger>
          <TabsTrigger value="history">Histórico</TabsTrigger>
          <TabsTrigger value="analysis">Análise</TabsTrigger>
          <TabsTrigger value="alerts">Alertas</TabsTrigger>
          <TabsTrigger value="settings">Configurações</TabsTrigger>
        </TabsList>

        {/* Dashboard Principal */}
        <TabsContent value="dashboard" className="space-y-4">
          {/* Medições Principais */}
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Vazão Atual</CardTitle>
                <DropletIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{currentFlow} L/min</div>
                <p className="text-xs text-muted-foreground">Média: 2.8 L/min</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Volume Total</CardTitle>
                <History className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalVolume.toFixed(2)} L</div>
                <p className="text-xs text-muted-foreground">Desde a instalação</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Consumo Hoje</CardTitle>
                <Calendar className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{dailyUsage.toFixed(2)} L</div>
                <p className="text-xs text-muted-foreground">R$ {calculateCost(dailyUsage)}</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Consumo Mensal</CardTitle>
                <BarChart3 className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{monthlyUsage.toFixed(2)} L</div>
                <p className="text-xs text-muted-foreground">R$ {calculateCost(monthlyUsage)}</p>
              </CardContent>
            </Card>
          </div>

          {/* Caixa d'Água - Resumo */}
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle>Nível da Caixa d'Água</CardTitle>
              <Tank className="h-5 w-5 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-4">
                <div className="w-full">
                  <Progress value={tankLevel} className="h-4" />
                  <div className="flex justify-between mt-2">
                    <span className="text-sm text-muted-foreground">0%</span>
                    <span className="text-sm text-muted-foreground">50%</span>
                    <span className="text-sm text-muted-foreground">100%</span>
                  </div>
                </div>
                <div className="text-right min-w-[100px]">
                  <div className="text-2xl font-bold">{tankLevel.toFixed(1)}%</div>
                  <Badge variant={getTankStatus().color as any}>{getTankStatus().status}</Badge>
                </div>
              </div>
              <p className="text-sm mt-2">
                Volume atual: {getCurrentTankVolume()} L de {tankCapacity} L
              </p>
            </CardContent>
          </Card>

          {/* Alertas */}
          <div className="space-y-2">
            {leakDetected && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Vazamento Detectado!</AlertTitle>
                <AlertDescription>
                  Fluxo contínuo detectado nas últimas 6 horas. Verifique suas instalações.
                </AlertDescription>
              </Alert>
            )}

            {tankLevel <= tankAlertLow && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertTitle>Nível Crítico na Caixa d'Água!</AlertTitle>
                <AlertDescription>
                  A caixa está com apenas {tankLevel.toFixed(1)}% da capacidade ({getCurrentTankVolume()} litros).
                </AlertDescription>
              </Alert>
            )}

            {tankLevel >= tankAlertHigh && (
              <Alert>
                <Droplets className="h-4 w-4" />
                <AlertTitle>Caixa d'Água Quase Cheia</AlertTitle>
                <AlertDescription>
                  A caixa está com {tankLevel.toFixed(1)}% da capacidade ({getCurrentTankVolume()} litros).
                </AlertDescription>
              </Alert>
            )}
          </div>
        </TabsContent>

        {/* Caixa d'Água */}
        <TabsContent value="tank" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            {/* Visualização da Caixa */}
            <Card>
              <CardHeader>
                <CardTitle>Nível da Caixa d'Água</CardTitle>
                <CardDescription>Monitoramento em tempo real</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col items-center">
                  {/* Representação visual da caixa */}
                  <div className="w-40 h-60 border-2 border-gray-300 rounded-md relative mb-4">
                    <div
                      className={`absolute bottom-0 left-0 right-0 transition-all duration-1000 rounded-b-sm
                        ${
                          tankLevel <= tankAlertLow
                            ? "bg-red-500"
                            : tankLevel <= tankAlertMid
                              ? "bg-yellow-500"
                              : tankLevel <= tankAlertHigh
                                ? "bg-blue-500"
                                : "bg-green-500"
                        }`}
                      style={{ height: `${tankLevel}%` }}
                    />

                    {/* Marcações de nível */}
                    <div className="absolute top-0 left-0 right-0 h-full">
                      <div className="absolute top-[10%] w-full border-t border-gray-400 border-dashed">
                        <span className="absolute -right-8 -top-2 text-xs">90%</span>
                      </div>
                      <div className="absolute top-[50%] w-full border-t border-gray-400 border-dashed">
                        <span className="absolute -right-8 -top-2 text-xs">50%</span>
                      </div>
                      <div className="absolute top-[80%] w-full border-t border-gray-400 border-dashed">
                        <span className="absolute -right-8 -top-2 text-xs">20%</span>
                      </div>
                    </div>
                  </div>

                  <div className="text-center">
                    <div className="text-3xl font-bold">{tankLevel.toFixed(1)}%</div>
                    <div className="text-lg">
                      {getCurrentTankVolume()} / {tankCapacity} L
                    </div>
                    <Badge className="mt-2" variant={getTankStatus().color as any}>
                      {getTankStatus().status}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Estatísticas e Controles */}
            <Card>
              <CardHeader>
                <CardTitle>Estatísticas da Caixa</CardTitle>
                <CardDescription>Informações e controles</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Capacidade Total:</span>
                    <span className="font-medium">{tankCapacity} L</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Volume Atual:</span>
                    <span className="font-medium">{getCurrentTankVolume()} L</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Espaço Disponível:</span>
                    <span className="font-medium">{(tankCapacity - Number(getCurrentTankVolume())).toFixed(0)} L</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Status:</span>
                    <Badge variant={getTankStatus().color as any}>{getTankStatus().status}</Badge>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="font-medium mb-2">Alertas da Caixa</h4>
                  <div className="flex items-center justify-between mb-2">
                    <span>Ativar alertas</span>
                    <Button
                      variant={tankAlertsEnabled ? "default" : "outline"}
                      size="sm"
                      onClick={() => setTankAlertsEnabled(!tankAlertsEnabled)}
                    >
                      {tankAlertsEnabled ? <Bell className="h-4 w-4 mr-1" /> : <BellOff className="h-4 w-4 mr-1" />}
                      {tankAlertsEnabled ? "Ativado" : "Desativado"}
                    </Button>
                  </div>

                  <div className="space-y-4 mt-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Alerta de Nível Baixo: {tankAlertLow}%</span>
                      </div>
                      <Slider
                        value={[tankAlertLow]}
                        min={5}
                        max={40}
                        step={5}
                        onValueChange={(value) => setTankAlertLow(value[0])}
                        disabled={!tankAlertsEnabled}
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Alerta de Nível Médio: {tankAlertMid}%</span>
                      </div>
                      <Slider
                        value={[tankAlertMid]}
                        min={40}
                        max={70}
                        step={5}
                        onValueChange={(value) => setTankAlertMid(value[0])}
                        disabled={!tankAlertsEnabled}
                      />
                    </div>

                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm">Alerta de Nível Alto: {tankAlertHigh}%</span>
                      </div>
                      <Slider
                        value={[tankAlertHigh]}
                        min={70}
                        max={95}
                        step={5}
                        onValueChange={(value) => setTankAlertHigh(value[0])}
                        disabled={!tankAlertsEnabled}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Histórico de Nível */}
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Nível</CardTitle>
              <CardDescription>Variação nas últimas 24 horas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] w-full">
                <div className="flex items-end justify-between h-full">
                  {tankHistory.map((value, index) => (
                    <div
                      key={index}
                      className={`w-12 rounded-t ${
                        value <= tankAlertLow
                          ? "bg-red-500"
                          : value <= tankAlertMid
                            ? "bg-yellow-500"
                            : value <= tankAlertHigh
                              ? "bg-blue-500"
                              : "bg-green-500"
                      }`}
                      style={{ height: `${value}%` }}
                    />
                  ))}
                </div>
              </div>
              <div className="flex justify-between mt-2 text-sm text-muted-foreground">
                <span>-24h</span>
                <span>-18h</span>
                <span>-12h</span>
                <span>-8h</span>
                <span>-4h</span>
                <span>Agora</span>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Histórico */}
        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Histórico de Consumo</CardTitle>
              <CardDescription>Últimos 6 dias de consumo</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] w-full">
                {/* Aqui você pode adicionar um gráfico de barras ou linha */}
                <div className="flex items-end justify-between h-full">
                  {dailyData.map((value, index) => (
                    <div
                      key={index}
                      className="w-12 bg-primary rounded-t"
                      style={{ height: `${(value / Math.max(...dailyData)) * 100}%` }}
                    />
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Consumo Mensal</CardTitle>
              <CardDescription>Últimos 6 meses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[200px] w-full">
                <div className="flex items-end justify-between h-full">
                  {monthlyData.map((value, index) => (
                    <div
                      key={index}
                      className="w-12 bg-primary rounded-t"
                      style={{ height: `${(value / Math.max(...monthlyData)) * 100}%` }}
                    />
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Análise */}
        <TabsContent value="analysis" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle>Análise de Consumo</CardTitle>
                <CardDescription>Comparação com média histórica</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Consumo Atual</span>
                    <Badge variant={dailyUsage > 120 ? "destructive" : "default"}>{dailyUsage.toFixed(2)} L</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Média Diária</span>
                    <Badge>120 L</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Variação</span>
                    <Badge variant={dailyUsage > 120 ? "destructive" : "default"}>
                      {(((dailyUsage - 120) / 120) * 100).toFixed(1)}%
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Previsão de Consumo</CardTitle>
                <CardDescription>Baseado no histórico</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Previsão Mensal</span>
                    <Badge>{(dailyUsage * 30).toFixed(0)} L</Badge>
                  </div>
                  <div className="flex justify-between">
                    <span>Custo Estimado</span>
                    <Badge variant="outline">R$ {calculateCost(dailyUsage * 30)}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Alertas */}
        <TabsContent value="alerts" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configuração de Alertas</CardTitle>
              <CardDescription>Defina limites para notificações</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span>Alerta de Consumo Diário</span>
                <Badge>150 L</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Alerta de Vazamento</span>
                <Badge>6 horas de fluxo contínuo</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span>Alerta de Meta Mensal</span>
                <Badge>90% da meta</Badge>
              </div>

              <div className="pt-2 border-t mt-2">
                <h4 className="font-medium mb-2">Alertas da Caixa d'Água</h4>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span>Nível Baixo</span>
                    <Badge variant="destructive">{tankAlertLow}%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Nível Médio</span>
                    <Badge variant="warning">{tankAlertMid}%</Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span>Nível Alto</span>
                    <Badge variant="success">{tankAlertHigh}%</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Histórico de Alertas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {tankLevel <= tankAlertLow && (
                  <Alert variant="destructive">
                    <Tank className="h-4 w-4" />
                    <AlertTitle>Nível Crítico na Caixa d'Água</AlertTitle>
                    <AlertDescription>Apenas {tankLevel.toFixed(1)}% de capacidade - Agora</AlertDescription>
                  </Alert>
                )}

                {leakDetected && (
                  <Alert variant="destructive">
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>Vazamento Detectado</AlertTitle>
                    <AlertDescription>Fluxo contínuo detectado - 28/02/2024 14:30</AlertDescription>
                  </Alert>
                )}

                <Alert>
                  <Tank className="h-4 w-4" />
                  <AlertTitle>Nível Médio na Caixa d'Água</AlertTitle>
                  <AlertDescription>50% de capacidade atingida - 28/02/2024 10:15</AlertDescription>
                </Alert>

                <Alert>
                  <Target className="h-4 w-4" />
                  <AlertTitle>Meta Mensal Próxima</AlertTitle>
                  <AlertDescription>90% da meta mensal atingida - 27/02/2024 18:45</AlertDescription>
                </Alert>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Configurações */}
        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Configurações do Sistema</CardTitle>
              <CardDescription>Ajuste os parâmetros do medidor</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid gap-4">
                <div className="flex justify-between items-center">
                  <span>Fator de Calibração</span>
                  <Badge>7.5 pulsos/L</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Custo por m³</span>
                  <Badge>R$ {(costPerLiter * 1000).toFixed(2)}</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Meta Mensal</span>
                  <Badge>{monthlyTarget} L</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span>Intervalo de Leitura</span>
                  <Badge>1 segundo</Badge>
                </div>

                <div className="pt-2 border-t mt-2">
                  <h4 className="font-medium mb-2">Configurações da Caixa d'Água</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span>Capacidade da Caixa</span>
                      <div className="flex items-center gap-2">
                        <input
                          type="number"
                          value={tankCapacity}
                          onChange={(e) => setTankCapacity(Number(e.target.value))}
                          className="w-20 h-8 px-2 border rounded text-right"
                          min="100"
                          max="10000"
                          step="100"
                        />
                        <span>L</span>
                      </div>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Tipo de Sensor</span>
                      <Badge>Ultrassônico</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span>Altura da Caixa</span>
                      <Badge>100 cm</Badge>
                    </div>
                  </div>
                </div>
              </div>
              <Button className="w-full">Salvar Configurações</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

